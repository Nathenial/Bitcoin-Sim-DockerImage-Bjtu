GUI changes
--------

- A new menu item to restore a wallet from a backup file has been added (#471).