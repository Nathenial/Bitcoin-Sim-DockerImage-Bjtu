New RPCs
--------

- A new `gettxspendingprevout` RPC has been added, which scans the mempool to find
  transactions spending any of the given outpoints. (#24408)